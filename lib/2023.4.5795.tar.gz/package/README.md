DayPilot Pro for JavaScript (React)
===================================

Product information
-------------------
https://javascript.daypilot.org/

NPM package
-----------
https://npm.daypilot.org/